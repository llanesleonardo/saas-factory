# AGENTS

**Role definitions** live in this directory as `*-agent.md`. Invoke them in Cursor with `@agents/<filename>.md`.

**Every invocation:** agents must lead with **Resources & dependencies** (see **`organizational_memory/AGENTS.md` → Resources manifest**).

**Modern tooling catalogue:** each **`agents/*-agent.md`** has **`## Toolkit — modern stack`** (and extended **`Toolkit`** where noted).

**Router, diagrams, per-role use cases, and lesson routing** live in **`organizational_memory/AGENTS.md`**.

**Factory process, architecture, mission control, lean, GitHub Projects setup, agent run log, QMS:** **`organizational_memory/README.md`**.

**QMS raw record spec (all roles):** **`agents/agent-record-for-qms.md`**.
